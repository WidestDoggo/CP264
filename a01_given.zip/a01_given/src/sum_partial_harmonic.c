/**
 * -------------------------------------
 * @file  sum_partial_harmonic.c
 * Assignment 1 Functions Source Code File
 * -------------------------------------
 * @author name, id, email
 *
 * @version 2025-01-05
 *
 * -------------------------------------
 */
#include "sum_partial_harmonic.h"

double sum_partial_harmonic(int n) {

    // your code here

    return 0.0;
}
