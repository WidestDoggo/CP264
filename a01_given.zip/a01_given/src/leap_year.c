/**
 * -------------------------------------
 * @file  leap_year.c
 * Assignment 1 Functions Header File
 * -------------------------------------
 * @author name, id, email
 *
 * @version 2025-01-05
 *
 * -------------------------------------
 */
#include "leap_year.h"

bool leap_year(int year) {

    // your code here

    return false;
}
