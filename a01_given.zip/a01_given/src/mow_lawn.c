/**
 * -------------------------------------
 * @file  mow_lawn.c
 * Assignment 1 Functions Source Code File
 * -------------------------------------
 * @author name, id, email
 *
 * @version 2025-01-05
 *
 * -------------------------------------
 */
#include <math.h>

#include "mow_lawn.h"

int mow_lawn(double width, double length, double speed) {

    // your code here

    return 0;
}
