/**
 * -------------------------------------
 * @file  date_convert.c
 * Assignment 1 Functions Source Code File
 * -------------------------------------
 * @author name, id, email
 *
 * @version 2025-01-05
 *
 * -------------------------------------
 */
#include <math.h>

#include "date_convert.h"

int date_convert(int date_number) {

    // your code here

    return 0;
}
