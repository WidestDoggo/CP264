/**
 * -------------------------------------
 * @file  sum_even.c
 * Assignment 1 Functions Source Code File
 * -------------------------------------
 * @author name, id, email
 *
 * @version 2025-01-05
 *
 * -------------------------------------
 */
#include "sum_even.h"

int sum_even(int n) {

    // your code here

    return 0;
}
