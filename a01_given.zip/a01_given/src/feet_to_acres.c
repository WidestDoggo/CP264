/**
 * -------------------------------------
 * @file  feet_to_acres.c
 * Assignment 1 Functions Source Code File
 * -------------------------------------
 * @author name, id, email
 *
 * @version 2025-01-05
 *
 * -------------------------------------
 */
#include <math.h>

#include "feet_to_acres.h"

double feet_to_acres(int square_feet) {

    // your code here

    return 0.0;
}

