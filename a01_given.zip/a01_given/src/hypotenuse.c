/**
 * -------------------------------------
 * @file  hypotenuse.c
 * Assignment 1 Functions Source Code File
 * -------------------------------------
 * @author name, id, email
 *
 * @version 2025-01-05
 *
 * -------------------------------------
 */
#include <math.h>

#include "hypotenuse.h"

double hypotenuse(double side1, double side2) {

    // your code here

    return 0.0;
}
