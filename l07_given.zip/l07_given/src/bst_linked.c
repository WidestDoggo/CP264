/** @file  bst_linked.c
 * -------------------------------------
 * @author David Brown, 123456789, dbrown@wlu.ca
 *
 * @version 2025-09-01
 *
 * -------------------------------------
 */
#include "bst_linked.h"

// Macro for comparing node heights
#define MAX_HEIGHT(a,b) ((a) > (b) ? a : b)

//==================================================================================
// Private Helper Functions

/**
 * Private helper function to print contents of BST in preorder.
 *
 * @param node - pointer to bst_node
 */
static void bst_print_aux(bst_node *node) {
    char string[200];

    if(node != NULL) {
        data_string(string, sizeof string, &node->item);
        printf("%s, ", string);
        bst_print_aux(node->left);
        bst_print_aux(node->right);
    }
    return;
}

/**
 * Initializes a new BST node with a copy of item.
 *
 * @param item - pointer to the value to copy to the node
 * @return - a pointer to a new BST node, NULL if memory not allocated
 */
static bst_node* bst_node_initialize(const data_type *item) {
    bst_node *node = malloc(sizeof *node);

    if(node != NULL) {
        data_copy(&node->item, item);
        node->height = 1;
        node->left = NULL;
        node->right = NULL;
    }
    return node;
}

/**
 * Determines the height of node - empty nodes have a height of 0.
 *
 * @param node - pointer to a BST node
 * @return - the height of the current node
 */
static int bst_node_height(const bst_node *node) {
    int height = 0;

    if(node != NULL) {
        height = node->height;
    }
    return height;
}

/**
 * Updates the height of a node. Its height is the max of the heights of its
 * child nodes, plus 1.
 *
 * @param node - pointer to a BST node
 */
static void bst_update_height(bst_node *node) {
    int left_height = bst_node_height(node->left);
    int right_height = bst_node_height(node->right);

    node->height = MAX_HEIGHT(left_height, right_height) + 1;
    return;
}

/**
 * Inserts a copy of item into source. Insertion must preserve the BST definition.
 * item may appear only once in source.
 *
 * @param source - pointer to a BST
 * @param node - pointer to a BST node
 * @param item - the item to insert
 * @return - true if item inserted, false otherwise
 */
static bool bst_insert_aux(bst_linked *source, bst_node **node, const data_type *item) {
    bool inserted = false;

    if(*node == NULL) {
        // Base case: add a new node containing the item.
        *node = bst_node_initialize(item);
        source->count += 1;
        inserted = true;
    } else {
        // Compare the node data_type against the new item.
        int comp = data_compare(item, &(*node)->item);

        if(comp < 0) {
            // General case: check the left subsource.
            inserted = bst_insert_aux(source, &(*node)->left, item);
        } else if(comp > 0) {
            // General case: check the right subsource.
            inserted = bst_insert_aux(source, &(*node)->right, item);
        }
    }
    if(inserted) {
        // Update the node height if any of its children have been changed.
        bst_update_height(*node);
    }
    return inserted;
}

// other auxiliary functions here

//==================================================================================
// Functions

bst_linked* bst_initialize() {
    // Allocate memory to the list header
    bst_linked *source = malloc(sizeof *source);

    if(source) {
        // Initialize the list structure
        source->root = NULL;
        source->count = 0;
    }
    // returns NULL if malloc fails
    return source;
}

void bst_destroy(bst_linked **source) {

    // your code here

    return;
}

bool bst_empty(const bst_linked *source) {

    // your code here

    return false;
}

int bst_count(const bst_linked *source) {

    // your code here

    return -1;
}

void bst_inorder(const bst_linked *source, data_type *items) {

    // your code here

    return;
}

void bst_preorder(const bst_linked *source, data_type *items) {

    // your code here

    return;
}

void bst_postorder(const bst_linked *source, data_type *items) {

    // your code here

    return;
}

bool bst_insert(bst_linked *source, const data_type *item) {
    return bst_insert_aux(source, &(source->root), item);
}

bool bst_retrieve(const bst_linked *source, const data_type *key, data_type *item) {

    // your code here

    return false;
}

bool bst_remove(bst_linked *source, const data_type *key, data_type *item) {

    // your code here

    return false;
}

bool bst_copy(bst_linked **target, const bst_linked *source) {

    // your code here

    return false;
}

bool bst_max(const bst_linked *source, data_type *item) {

    // your code here

    return false;
}

bool bst_min(const bst_linked *source, data_type *item) {

    // your code here

    return false;
}

int bst_leaf_count(const bst_linked *source) {

    // your code here

    return -1;
}

int bst_one_child_count(const bst_linked *source) {

    // your code here

    return -1;
}

int bst_two_child_count(const bst_linked *source) {

    // your code here

    return -1;
}

void bst_node_counts(const bst_linked *source, int *zero, int *one, int *two) {

    // your code here

    return;
}

bool bst_balanced(const bst_linked *source) {

    // your code here

    return false;
}

bool bst_valid(const bst_linked *source) {

    // your code here

    return false;
}

bool bst_equal(const bst_linked *target, const bst_linked *source) {

    // your code here

    return false;
}

void bst_print(const bst_linked *source) {
    // can print root height only if root is not NULL
    printf("  count: %d, height: %d, items:\n{", source->count, source->root ? source->root->height : 0);
    bst_print_aux(source->root);
    printf("}\n");
    return;
}
