/** @file  pq_linked.c
 * -------------------------------------
 * @author name, id, email
 *
 * @version 2025-09-01
 *
 * -------------------------------------
 */
//==================================================================================
// Includes
#include "pq_linked.h"

//==================================================================================
// Functions

pq_linked* pq_initialize() {

    // your code here

    return NULL;
}

void pq_destroy(pq_linked **source) {

    // your code here

    return;
}

bool pq_empty(const pq_linked *source) {

    // your code here

    return false;
}

int pq_count(const pq_linked *source) {

    // your code here

    return -1;
}

bool pq_insert(pq_linked *source, const data_type *item) {

    // your code here

    return false;
}

bool pq_peek(const pq_linked *source, data_type *item) {

    // your code here

    return false;
}

bool pq_remove(pq_linked *source, data_type *item) {

    // your code here

    return false;
}

bool pq_equal(const pq_linked *source, const pq_linked *target) {

    // your code here

    return false;
}

bool pq_copy(pq_linked **target, const pq_linked *source) {

    // your code here

    return false;
}

void pq_print(const pq_linked *source) {
    char string[200];
    pq_node *curr = source->front;

    while(curr != NULL) {
        data_string(string, sizeof string, &curr->item);
        printf("%s\n", string);
        curr = curr->next;
    }
    return;
}
