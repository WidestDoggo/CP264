/** @file  list_linked.c
 * -------------------------------------
 * @author name, id, email
 *
 * @version 2025-09-01
 *
 * -------------------------------------
 */
#include "list_linked.h"

//==================================================================================
// Private Helper Functions

// add static helper functions here

//==================================================================================
// Functions

list_linked* list_initialize() {

    // your code here

    return NULL;
}

void list_destroy(list_linked **source) {

    // your code here

    return;
}

bool list_empty(const list_linked *source) {

    // your code here

    return false;
}

int list_count(const list_linked *source) {

    // your code here

    return -1;
}

bool list_append(list_linked *source, const data_type *item) {

    // your code here

    return false;
}

bool list_prepend(list_linked *source, data_type *item) {

    // your code here

    return false;
}

bool list_insert(list_linked *source, int i, data_type *item) {

    // your code here

    return false;
}

bool list_peek(const list_linked *source, data_type *item) {

    // your code here

    return false;
}

bool list_key_find(const list_linked *source, const data_type *key, data_type *item) {

    // your code here

    return false;
}

bool list_key_remove(list_linked *source, const data_type *key, data_type *item) {

    // your code here

    return false;
}

bool list_remove_front(list_linked *source, data_type *item) {

    // your code here

    return false;
}

int list_key_index(const list_linked *source, const data_type *key) {

    // your code here

    return false;
}

bool list_key_contains(const list_linked *source, const data_type *key) {

    // your code here

    return false;
}

int list_key_count(const list_linked *source, const data_type *key) {

    // your code here

    return -1;
}

bool list_index_remove(list_linked *source, int i, data_type *item) {

    // your code here

    return false;
}

bool list_max(const list_linked *source, data_type *item) {

    // your code here

    return false;
}

bool list_min(const list_linked *source, data_type *item) {

    // your code here

    return false;
}

void list_clean(list_linked *source) {

    // your code here

    return;
}

bool list_equal(const list_linked *target, const list_linked *source) {

    // your code here

    return false;
}

void list_combine(list_linked *target, list_linked *source1, list_linked *source2) {

    // your code here

    return;
}

void list_split_alt(list_linked *target1, list_linked *target2, list_linked *source) {

    // your code here

    return;
}

void list_split(list_linked *target1, list_linked *target2, list_linked *source) {

    // your code here

    return;
}

void list_split_key(list_linked *target1, list_linked *target2, list_linked *source, data_type *key) {

    // your code here

    return;
}

bool list_copy(list_linked **target, const list_linked *source) {

    // your code here

    return false;
}

// Prints the items in a list from front to rear.
void list_print(const list_linked *source) {
    char string[200];
    list_node *current = source->front;

    while(current != NULL) {
        data_string(string, sizeof string, &current->item);
        printf("%s\n", string);
        current = current->next;
    }
    return;
}
