/** @file  queue_linked.c
 * -------------------------------------
 * @author name, id, email
 *
 * @version 2025-09-01
 *
 * -------------------------------------
 */
//==================================================================================
// Includes
#include "queue_linked.h"

//==================================================================================
// Local Helper Functions

// your code here, if any

//==================================================================================
// Functions

queue_linked* queue_initialize() {

    // your code here

    return NULL;
}

void queue_destroy(queue_linked **source) {

    // your code here

    return;
}

bool queue_empty(const queue_linked *source) {

    // your code here

    return false;
}

int queue_count(const queue_linked *source) {

    // your code here

    return -1;
}

bool queue_insert(queue_linked *source, const data_type *item) {

    // your code here

    return false;
}

bool queue_peek(const queue_linked *source, data_type *item) {

    // your code here

    return false;
}

bool queue_remove(queue_linked *source, data_type *item) {

    // your code here

    return false;
}

bool queue_equal(const queue_linked *source, const queue_linked *target) {

    // your code here

    return false;
}

bool queue_copy(queue_linked **target, const queue_linked *source) {

    // your code here

    return false;
}

void queue_append(queue_linked *target, queue_linked *source) {

    // your code here

    return;
}

void queue_combine(queue_linked *target, queue_linked *source1, queue_linked *source2) {

    // your code here

    return;
}

void queue_split_alt(queue_linked *target1, queue_linked *target2, queue_linked *source) {

    // your code here

    return;
}

void queue_print(const queue_linked *source) {
    char string[200];
    queue_node *current = source->front;

    while(current != NULL) {
        data_string(string, sizeof string, &current->item);
        printf("%s\n", string);
        current = current->next;
    }
    return;
}
