var by__ptr_8c =
[
    [ "fill_squares_by_ptr", "by__ptr_8c.htm#a50e7f42875d549e8ee977ef4db976e33", null ],
    [ "fill_values_by_ptr", "by__ptr_8c.htm#ac865fb0931d42df293b822d60251f4e9", null ],
    [ "print_by_ptr", "by__ptr_8c.htm#a8311f311fbffe10c4cece5d07b4da474", null ]
];