/** @file  strings_with_substring.c
 * -------------------------------------
 * @author name, id, email
 *
 * @version 2025-09-01
 *
 * -------------------------------------
 */
#include "functions.h"

void strings_with_substring(strings_array *source, char *substr) {

    // your code here

}
