/** @file  strings_length.c
 * -------------------------------------
 * @author name, id, email
 *
 * @version 2025-09-01
 *
 * -------------------------------------
 */
#include "functions.h"

void strings_length(strings_array *source, FILE *fp_short, FILE *fp_long, int length) {

    // your code here

}
