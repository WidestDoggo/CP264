var structstrings__array =
[
    [ "capacity", "structstrings__array.htm#a3e2873fb5cd78bacba61ec3e056ad97b", null ],
    [ "count", "structstrings__array.htm#ad0eef26e67166e43eb3bd41290164409", null ],
    [ "strings", "structstrings__array.htm#ad09f844d2e814adb4ed99f540f98b99c", null ]
];