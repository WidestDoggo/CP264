var functions_8h =
[
    [ "strings_array", "structstrings__array.htm", "structstrings__array" ],
    [ "free_strings_array", "functions_8h.htm#ac079443142f613138168f5f267edece6", null ],
    [ "initialize_strings_array", "functions_8h.htm#a33573e7f7b01256bfcceccab7e036bef", null ],
    [ "read_strings", "functions_8h.htm#a35231505985ced9edf5596f639c85b27", null ],
    [ "strings_length", "functions_8h.htm#a9c65bff67e7d584e15e8d8c8254a6193", null ],
    [ "strings_with_substring", "functions_8h.htm#a26dca4591982b77da1150bb17dff935b", null ]
];