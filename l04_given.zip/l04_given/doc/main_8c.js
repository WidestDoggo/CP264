var main_8c =
[
    [ "CAPACITY", "main_8c.htm#a91fbe6020a4bbd73084f0681b9092479", null ],
    [ "IN_FILE", "main_8c.htm#a9a678d097f097c46768252d37a2bcc01", null ],
    [ "LONG_FILE", "main_8c.htm#a96ce2acd30da6f091822c98e778297ec", null ],
    [ "MAX_LINE", "main_8c.htm#a842ed03f27719bc87666bfd1f75415b8", null ],
    [ "SHORT_FILE", "main_8c.htm#ae262b34c650329f4896e6c3adeaf99d0", null ],
    [ "main", "main_8c.htm#a0ddf1224851353fc92bfbff6f499fa97", null ],
    [ "test_strings_length", "main_8c.htm#a101378f864160b657a4d78a815974371", null ],
    [ "test_strings_with_substring", "main_8c.htm#aaab4d657b4550a1bcc3ae39d4e4d0c90", null ]
];