var strings__array_8c =
[
    [ "free_strings_array", "strings__array_8c.htm#ac079443142f613138168f5f267edece6", null ],
    [ "initialize_strings_array", "strings__array_8c.htm#a33573e7f7b01256bfcceccab7e036bef", null ],
    [ "read_strings", "strings__array_8c.htm#a35231505985ced9edf5596f639c85b27", null ]
];