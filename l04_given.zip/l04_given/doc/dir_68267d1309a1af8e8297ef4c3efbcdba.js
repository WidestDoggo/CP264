var dir_68267d1309a1af8e8297ef4c3efbcdba =
[
    [ "functions.h", "functions_8h.htm", "functions_8h" ],
    [ "main.c", "main_8c.htm", "main_8c" ],
    [ "strings_array.c", "strings__array_8c.htm", "strings__array_8c" ],
    [ "strings_length.c", "strings__length_8c.htm", "strings__length_8c" ],
    [ "strings_with_substring.c", "strings__with__substring_8c.htm", "strings__with__substring_8c" ]
];