/* list_dynamic.c */
/** @file  list_dynamic.c
 * -------------------------------------
 * @author name, id, email
 *
 * @version 2025-09-01
 *
 * -------------------------------------
 */
#include "list_dynamic.h"

// ==============================================================================================
// Functions

bool list_initialize(list_dynamic *source, int capacity) {

    bool initialized = false;

    if(capacity < 1) {
        capacity = LIST_INIT_CAPACITY;
    }
    source->count = 0;
    source->capacity = 0;
    source->items = malloc(capacity * sizeof *source->items);

    if(source->items != NULL) {
        source->capacity = capacity;
        initialized = true;
    } else {
        source->items = NULL;
    }
    return initialized;
}

void list_destroy(list_dynamic *source) {

    free(source->items);
    source->items = NULL;
    source->capacity = 0;
    source->count = 0;
    return;
}

bool list_empty(const list_dynamic *source) {

    return source->count == 0;
}

int list_count(const list_dynamic *source) {

    return source->count;
}

bool list_append(list_dynamic *source, const data_type *item) {

    bool appended = true;

    if(source->count == source->capacity) {
        int capacity = source->capacity * 2 + 1;
        data_type *ptr = realloc(source->items, capacity * sizeof *source->items);

        if(ptr == NULL) {
            appended = false;
        } else {
            source->items = ptr;
            source->capacity = capacity;
        }
    }

    if(appended) {
        data_copy(&(source->items[source->count]), item);
        source->count += 1;
    }
    return appended;
}

bool list_insert(list_dynamic *source, const data_type *item, int i) {

    bool inserted = true;

    if(i < 0) {
        i = 0;
    } else if(i > source->count) {
        i = source->count;
    }

    if(source->count == source->capacity) {
        int capacity = source->capacity * 2 + 1;
        data_type *ptr = realloc(source->items, capacity * sizeof *source->items);

        if(ptr == NULL) {
            inserted = false;
        } else {
            source->items = ptr;
            source->capacity = capacity;
        }
    }

    if(inserted) {
        for(int j = source->count; j > i; j--) {
            source->items[j] = source->items[j - 1];
        }
        data_copy(&(source->items[i]), item);
        source->count += 1;
    }
    return inserted;
}

bool list_peek(const list_dynamic *source, data_type *item) {

    bool peeked = false;

    if(source->count > 0) {
        data_copy(item, &(source->items[0]));
        peeked = true;
    }
    return peeked;
}

bool list_key_find(const list_dynamic *source, const data_type *key, data_type *item) {

    bool found = false;

    for(int i = 0; i < source->count && !found; i++) {
        if(data_compare(&(source->items[i]), key) == 0) {
            data_copy(item, &(source->items[i]));
            found = true;
        }
    }
    return found;
}

bool list_key_remove(list_dynamic *source, const data_type *key, data_type *item) {

    int i = list_key_index(source, key);
    return list_index_remove(source, i, item);
}

int list_key_index(const list_dynamic *source, const data_type *key) {

    int index = -1;

    for(int i = 0; i < source->count && index == -1; i++) {
        if(data_compare(&(source->items[i]), key) == 0) {
            index = i;
        }
    }
    return index;
}

bool list_key_contains(const list_dynamic *source, const data_type *key) {

    return list_key_index(source, key) != -1;
}

int list_key_count(const list_dynamic *source, const data_type *key) {

    int count = 0;

    for(int i = 0; i < source->count; i++) {
        if(data_compare(&(source->items[i]), key) == 0) {
            count++;
        }
    }
    return count;
}

bool list_index_remove(list_dynamic *source, int i, data_type *item) {

    bool removed = false;

    if(i >= 0 && i < source->count) {
        // copy not required for remove
        *item = source->items[i];

        for(int j = i; j < source->count - 1; j++) {
            source->items[j] = source->items[j + 1];
        }
        source->count -= 1;
        removed = true;
    }
    return removed;
}

bool list_max(const list_dynamic *source, data_type *item) {

    bool found = false;

    if(source->count > 0) {
        int max_i = 0;

        for(int i = 1; i < source->count; i++) {
            if(data_compare(&(source->items[i]), &(source->items[max_i])) > 0) {
                max_i = i;
            }
        }
        data_copy(item, &(source->items[max_i]));
        found = true;
    }
    return found;
}

bool list_min(const list_dynamic *source, data_type *item) {

    bool found = false;

    if(source->count > 0) {
        int min_i = 0;

        for(int i = 1; i < source->count; i++) {
            if(data_compare(&(source->items[i]), &(source->items[min_i])) < 0) {
                min_i = i;
            }
        }
        data_copy(item, &(source->items[min_i]));
        found = true;
    }
    return found;
}

bool list_equal(const list_dynamic *source, const list_dynamic *target) {

    bool equals = false;

    if(source->count == target->count) {
        int i = 0;

        while((i < source->count) && (data_compare(&(source->items[i]), &(target->items[i])) == 0)) {
            i++;
        }
        equals = (i == source->count);
    }
    return equals;
}

bool list_copy(list_dynamic *target, const list_dynamic *source) {

    list_destroy(target);
    bool copied = list_initialize(target, source->capacity);

    if(copied) {
        target->count = source->count;

        for(int i = 0; i < source->count; i++) {
            data_copy(&(target->items[i]), &(source->items[i]));
        }
    }
    return copied;
}

void list_print(const list_dynamic *source) {
    char string[200];
    printf("capacity: %d\n", source->capacity);
    printf("count: %d\n", source->count);
    printf("  values:\n");
    // Walk through stack from top to bottom using indexes.
    for(int i = 0; i < source->count; i++) {
        data_string(string, sizeof string, &(source->items[i]));
        printf("%s\n", string);
    }
    return;
}