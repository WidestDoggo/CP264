/* queue_dynamic.c */
/** @file  queue_dynamic.c
 * -------------------------------------
 * @author name, id, email
 *
 * @version 2025-09-01
 *
 * -------------------------------------
 */
#include "queue_dynamic.h"

// ==============================================================================================
// Functions

bool queue_initialize(queue_dynamic *source, int capacity) {

    bool initialized = false;

    if(capacity < 1) {
        capacity = QUEUE_INIT_CAPACITY;
    }
    source->count = 0;
    source->front = -1;
    source->rear = 0;
    source->capacity = 0;
    source->items = malloc(capacity * sizeof *source->items);

    if(source->items != NULL) {
        source->capacity = capacity;
        initialized = true;
    } else {
        source->items = NULL;
    }
    return initialized;
}

void queue_destroy(queue_dynamic *source) {

    free(source->items);
    source->items = NULL;
    source->capacity = 0;
    source->count = 0;
    source->front = -1;
    source->rear = 0;
    return;
}

bool queue_empty(const queue_dynamic *source) {

    return source->count == 0;
}

int queue_count(const queue_dynamic *source) {

    return source->count;
}

bool queue_insert(queue_dynamic *source, const data_type *item) {

    bool inserted = true;

    if(source->count == source->capacity) {
        int capacity = source->capacity * 2 + 1;
        data_type *items = malloc(capacity * sizeof *items);

        if(items == NULL) {
            inserted = false;
        } else {
            // copy existing queue contents in correct order starting at index 0
            for(int i = 0; i < source->count; i++) {
                int idx = (source->front + i) % source->capacity;
                data_copy(&(items[i]), &(source->items[idx]));
            }
            free(source->items);
            source->items = items;
            source->capacity = capacity;
            source->front = (source->count > 0) ? 0 : -1;
            source->rear = source->count;
        }
    }

    if(inserted) {
        if(source->count == 0) {
            source->front = 0;
            source->rear = 0;
        }
        data_copy(&(source->items[source->rear]), item);
        source->rear = (source->rear + 1) % source->capacity;
        source->count += 1;
    }
    return inserted;
}

bool queue_peek(const queue_dynamic *source, data_type *item) {

    bool peeked = false;

    if(source->count > 0) {
        data_copy(item, &(source->items[source->front]));
        peeked = true;
    }
    return peeked;
}

bool queue_remove(queue_dynamic *source, data_type *item) {

    bool removed = false;

    if(source->count > 0) {
        // item removed from front - copy not required
        *item = source->items[source->front];
        source->front = (source->front + 1) % source->capacity;
        source->count -= 1;

        if(source->count == 0) {
            source->front = -1;
            source->rear = 0;
        }
        removed = true;
    }
    return removed;
}

bool queue_equal(const queue_dynamic *target, const queue_dynamic *source) {

    bool equals = false;

    if(target->count == source->count) {
        int i = 0;

        while(i < source->count) {
            int s_idx = (source->front + i) % source->capacity;
            int t_idx = (target->front + i) % target->capacity;

            if(data_compare(&(source->items[s_idx]), &(target->items[t_idx])) != 0) {
                break;
            }
            i++;
        }
        equals = (i == source->count);
    }
    return equals;
}

bool queue_copy(queue_dynamic *target, const queue_dynamic *source) {

    queue_destroy(target);
    bool copied = queue_initialize(target, source->capacity);

    if(copied) {
        target->count = source->count;

        if(source->count == 0) {
            target->front = -1;
            target->rear = 0;
        } else {
            target->front = 0;
            target->rear = source->count;

            for(int i = 0; i < source->count; i++) {
                int s_idx = (source->front + i) % source->capacity;
                data_copy(&(target->items[i]), &(source->items[s_idx]));
            }
        }
    }
    return copied;
}

void queue_print(const queue_dynamic *source) {
    char string[200];
    // Walk through queue from front to rear using indexes.
    printf("capacity: %d\n", source->capacity);
    printf("count: %d\n", source->count);
    printf("front: %d\n", source->front);
    printf("rear: %d\n", source->rear);
    printf("  values:\n");
    int temp = source->front;

    for(int i = 0; i < source->count; i++) {
        data_string(string, sizeof string, &(source->items[i]));
        printf("%s\n", string);
        temp = (temp + 1) % source->capacity;
    }
    return;
}