/* pq_dynamic.c */
/** @file  pq_dynamic.c
 * -------------------------------------
 * @author name, id, email
 *
 * @version 2025-09-01
 *
 * -------------------------------------
 */
#include "pq_dynamic.h"

// ==============================================================================================
// Functions

bool pq_initialize(pq_dynamic *source, int capacity) {

    bool initialized = false;

    if(capacity < 1) {
        capacity = PQ_INIT_CAPACITY;
    }
    source->count = 0;
    source->first = -1;
    source->capacity = 0;
    source->items = malloc(capacity * sizeof *source->items);

    if(source->items != NULL) {
        source->capacity = capacity;
        initialized = true;
    } else {
        source->items = NULL;
    }
    return initialized;
}

void pq_destroy(pq_dynamic *source) {

    free(source->items);
    source->items = NULL;
    source->capacity = 0;
    source->count = 0;
    source->first = -1;
    return;
}

bool pq_empty(const pq_dynamic *source) {

    return source->count == 0;
}

int pq_count(const pq_dynamic *source) {

    return source->count;
}

bool pq_insert(pq_dynamic *source, const data_type *item) {

    bool inserted = true;

    if(source->count == source->capacity) {
        int capacity = source->capacity * 2 + 1;
        data_type *ptr = realloc(source->items, capacity * sizeof *source->items);

        if(ptr == NULL) {
            inserted = false;
        } else {
            source->items = ptr;
            source->capacity = capacity;
        }
    }

    if(inserted) {
        data_copy(&(source->items[source->count]), item);
        if(source->first == -1) {
            source->first = 0;
        } else if(data_compare(item, &(source->items[source->first])) < 0) {
            // smaller value == higher priority
            source->first = source->count;
        }
        source->count += 1;
    }
    return inserted;
}

bool pq_peek(const pq_dynamic *source, data_type *item) {

    bool peeked = false;

    if(source->count > 0) {
        data_copy(item, &(source->items[source->first]));
        peeked = true;
    }
    return peeked;
}

bool pq_remove(pq_dynamic *source, data_type *item) {

    bool removed = false;

    if(source->count > 0) {
        // item removed from first - copy not required
        *item = source->items[source->first];

        // move last element into first position (if not already last)
        source->count -= 1;
        if(source->count == 0) {
            source->first = -1;
        } else {
            source->items[source->first] = source->items[source->count];

            // recompute first (min value)
            int first = 0;
            for(int i = 1; i < source->count; i++) {
                if(data_compare(&(source->items[i]), &(source->items[first])) < 0) {
                    first = i;
                }
            }
            source->first = first;
        }
        removed = true;
    }
    return removed;
}

bool pq_equal(const pq_dynamic *source, const pq_dynamic *target) {

    bool equals = false;

    if(source->count == target->count) {
        int i = 0;

        while((i < source->count) && (data_compare(&(source->items[i]), &(target->items[i])) == 0)) {
            i++;
        }
        equals = (i == source->count);
    }
    return equals;
}

bool pq_copy(pq_dynamic *target, const pq_dynamic *source) {

    pq_destroy(target);
    bool copied = pq_initialize(target, source->capacity);

    if(copied) {
        target->count = source->count;
        target->first = source->first;

        for(int i = 0; i < source->count; i++) {
            data_copy(&(target->items[i]), &(source->items[i]));
        }
    }
    return copied;
}

void pq_print(const pq_dynamic *source) {
    char string[200];
    printf("capacity: %d\n", source->capacity);
    printf("count: %d\n", source->count);
    printf("first: %d\n", source->first);
    printf("  values:\n");
    // Walk through stack from top to bottom using indexes.
    for(int i = 0; i < source->count; i++) {
        data_string(string, sizeof string, &(source->items[i]));
        printf("%s\n", string);
    }
    return;
}