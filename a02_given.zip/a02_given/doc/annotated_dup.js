var annotated_dup =
[
    [ "food_array", "structfood__array.htm", "structfood__array" ],
    [ "food_struct", "structfood__struct.htm", "structfood__struct" ]
];