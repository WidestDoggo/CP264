var food_8c =
[
    [ "food_compare", "food_8c.htm#ac81510f10e37300fb4442df18b861204", null ],
    [ "food_copy", "food_8c.htm#a6713a7fd116bae89f8e0aa0e118f5cd9", null ],
    [ "food_hash", "food_8c.htm#af3245d45450f8e05c9b094a6ca6158e2", null ],
    [ "food_init", "food_8c.htm#a494956adba1073849938a3c9d08e4e09", null ],
    [ "food_key", "food_8c.htm#a3f43a21e1390fd471d93ce4232ee971c", null ],
    [ "food_string", "food_8c.htm#a1007e16dcf4374853a765587fd557f43", null ],
    [ "origins_menu", "food_8c.htm#abc1dec4d8f73b1d02d850a0f499e1bc7", null ],
    [ "ORIGINS", "food_8c.htm#a5f9601c818e312b8b05794f038c19cc3", null ],
    [ "ORIGINS_COUNT", "food_8c.htm#a603c97f02ec3b1503c7024009dd5b678", null ]
];