var food__utilities_8h =
[
    [ "food_array", "structfood__array.htm", "structfood__array" ],
    [ "FOODS_CAPACITY", "food__utilities_8h.htm#acf44910a5a0f960bbc7eb07216a48c2d", null ],
    [ "food_array_init", "food__utilities_8h.htm#a1e312e8b7937a675f546921f56b0a8e7", null ],
    [ "food_get", "food__utilities_8h.htm#a98e8beaa267dc7922857c092b9524f95", null ],
    [ "food_read", "food__utilities_8h.htm#a8bfc602f9767b4052bcb22f64200de7b", null ],
    [ "food_write", "food__utilities_8h.htm#acc9b437ae5a3202fc87e2d787b47c802", null ],
    [ "foods_get_origin", "food__utilities_8h.htm#a1bcbb17290c68b9f97fc6939c9b60308", null ],
    [ "foods_get_vegetarian", "food__utilities_8h.htm#a465642677cdb0dc9db9c4068cec4f4d8", null ],
    [ "foods_read", "food__utilities_8h.htm#a52290c3e50afa59caf0784c249790c09", null ],
    [ "foods_write", "food__utilities_8h.htm#a9f8e5d288facf21293db0f1d840d61ad", null ]
];