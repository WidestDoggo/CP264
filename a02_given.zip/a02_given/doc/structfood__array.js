var structfood__array =
[
    [ "capacity", "structfood__array.htm#aa44409c9d213cef532326d4f06b56e56", null ],
    [ "count", "structfood__array.htm#a4723502ace5532c634649b8a555b2eed", null ],
    [ "items", "structfood__array.htm#ae89ee2101366cf618714039edb86fe08", null ]
];