var structfood__struct =
[
    [ "calories", "structfood__struct.htm#a8bf3b9eba92f4fb68094f8f2bb6140ff", null ],
    [ "is_vegetarian", "structfood__struct.htm#a5ba032f11a21d65b91bd6c277e85e836", null ],
    [ "name", "structfood__struct.htm#a139632d86dc95599109d6de1798d1967", null ],
    [ "origin", "structfood__struct.htm#a21aec56489371e7bb22c6891c6ae501a", null ]
];