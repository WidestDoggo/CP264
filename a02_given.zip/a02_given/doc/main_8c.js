var main_8c =
[
    [ "ALL_FOODS_FILE", "main_8c.htm#a6a60bc765220c37e9be8667d40d04657", null ],
    [ "CALORIES_1", "main_8c.htm#a2ceba13c27e36c25e497029ad9587706", null ],
    [ "CALORIES_2", "main_8c.htm#a7688c5e05a57e02675bf47cd89347159", null ],
    [ "FOOD", "main_8c.htm#ab4e2d1c36943e332ff82a95847532dc5", null ],
    [ "FOODS_FILE", "main_8c.htm#a63a23585c7ef0a8b0de473f7a9e7b25a", null ],
    [ "NAME_1", "main_8c.htm#a278b182e7d51ae16a04aa1b2356545d7", null ],
    [ "NAME_2", "main_8c.htm#a1725c9c61b0cbca2a6e67a594739511e", null ],
    [ "ONE_FOOD_FILE", "main_8c.htm#afb0909d137bf8a386ff136db595d4a5d", null ],
    [ "ORIGIN_1", "main_8c.htm#ac23df9858b80b97c8941c1690e6acb98", null ],
    [ "ORIGIN_2", "main_8c.htm#a36a1ef8020168da50351bedf6cd69749", null ],
    [ "SEP", "main_8c.htm#a95cf1ca63ff303311d342d1a53d51f38", null ],
    [ "TST", "main_8c.htm#ad03da240b462e9f42e2d083ac343c9ed", null ],
    [ "VEGETARIAN_1", "main_8c.htm#ac1e83ff6826eba8ebf804d3911f7d70f", null ],
    [ "VEGETARIAN_2", "main_8c.htm#a0810ecc5e8d93e299cb186e27c331905", null ],
    [ "main", "main_8c.htm#a0ddf1224851353fc92bfbff6f499fa97", null ]
];