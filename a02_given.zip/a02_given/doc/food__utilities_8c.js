var food__utilities_8c =
[
    [ "food_array_init", "food__utilities_8c.htm#a1e312e8b7937a675f546921f56b0a8e7", null ],
    [ "food_get", "food__utilities_8c.htm#a98e8beaa267dc7922857c092b9524f95", null ],
    [ "food_read", "food__utilities_8c.htm#a8bfc602f9767b4052bcb22f64200de7b", null ],
    [ "food_write", "food__utilities_8c.htm#acc9b437ae5a3202fc87e2d787b47c802", null ],
    [ "foods_get_origin", "food__utilities_8c.htm#a1bcbb17290c68b9f97fc6939c9b60308", null ],
    [ "foods_get_vegetarian", "food__utilities_8c.htm#a465642677cdb0dc9db9c4068cec4f4d8", null ],
    [ "foods_read", "food__utilities_8c.htm#a52290c3e50afa59caf0784c249790c09", null ],
    [ "foods_write", "food__utilities_8c.htm#a9f8e5d288facf21293db0f1d840d61ad", null ]
];