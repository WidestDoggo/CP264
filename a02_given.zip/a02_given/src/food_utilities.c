/** @file  food_utilities.c
 * -------------------------------------
 * @author name, id, email
 *
 * @version 2025-09-01
 *
 * -------------------------------------
 */
#include "food_utilities.h"

// ==============================================================================================
// Functions

void food_array_init(food_array *source) {

    // your code here

    return;
}

void food_get(food_struct *source) {

    // your code here

    return;
}

bool food_read(food_struct *source, const char *line) {

    // your code here

    return false;
}

void foods_read(FILE *fp, food_array *source) {

    // your code here

    return;
}

void food_write(FILE *fp, const food_struct *source) {

    // your code here

}

void foods_write(FILE *fp, const food_array *source) {

    // your code here

    return;
}

void foods_get_vegetarian(const food_array *source, food_array *target) {

    // your code here

    return;
}

void foods_get_origin(const food_array *source, food_array *target, int origin) {

    // your code here

    return;
}
