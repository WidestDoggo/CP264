/**
 * -------------------------------------
 * @file  int_array_read.c
 * -------------------------------------
 * @author name, id, email
 *
 * @version 2025-09-01
 *
 * -------------------------------------
 */
#include "functions.h"

void int_array_read(int *array, int size) {

    // your code here

}
