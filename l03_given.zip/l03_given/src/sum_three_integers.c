/**
 * -------------------------------------
 * @file  functions.c
 * -------------------------------------
 * @author name, id, email
 *
 * @version 2025-09-01
 *
 * -------------------------------------
 */
#include "functions.h"

int sum_three_integers(void) {

    // your code here

    return 0;
}
