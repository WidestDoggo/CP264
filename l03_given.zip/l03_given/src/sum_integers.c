/**
 * -------------------------------------
 * @file  sum_integers.c
 * -------------------------------------
 * @author name, id, email
 *
 * @version 2025-09-01
 *
 * -------------------------------------
 */
#include "functions.h"

int sum_integers(void) {

    // your code here

    return 0;
}
