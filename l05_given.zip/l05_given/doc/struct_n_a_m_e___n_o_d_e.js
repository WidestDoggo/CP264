var struct_n_a_m_e___n_o_d_e =
[
    [ "first_name", "struct_n_a_m_e___n_o_d_e.htm#a72b85a8f6916ea6edcd515d8fecf349b", null ],
    [ "last_name", "struct_n_a_m_e___n_o_d_e.htm#a690e9d9302c9b2240160ace230379554", null ],
    [ "next", "struct_n_a_m_e___n_o_d_e.htm#ac5fed5f936cc5fd0770f3dfff0510177", null ]
];