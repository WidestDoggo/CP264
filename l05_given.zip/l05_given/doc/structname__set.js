var structname__set =
[
    [ "count", "structname__set.htm#ae71b3d505482d93168b59b115b577fa9", null ],
    [ "front", "structname__set.htm#a33c49978d4fc4a2c59edff9c2176bf9e", null ],
    [ "rear", "structname__set.htm#a0e7e433b84e3eb9402f1c126c613af4e", null ]
];