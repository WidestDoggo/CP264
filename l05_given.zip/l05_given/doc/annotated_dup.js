var annotated_dup =
[
    [ "NAME_NODE", "struct_n_a_m_e___n_o_d_e.htm", "struct_n_a_m_e___n_o_d_e" ],
    [ "name_set", "structname__set.htm", "structname__set" ]
];