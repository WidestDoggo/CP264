var structpq__linked =
[
    [ "count", "structpq__linked.htm#a77c68bd8bc0adbddb472762fe0004dca", null ],
    [ "front", "structpq__linked.htm#ade4c06f07449c58463c115e65f0c3f3c", null ],
    [ "rear", "structpq__linked.htm#a6dd225c14bcb4d6f58e374d2a68cd091", null ]
];