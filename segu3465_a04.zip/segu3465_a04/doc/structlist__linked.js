var structlist__linked =
[
    [ "count", "structlist__linked.htm#a2d12df9bbf7114c9a2414c6e032cf264", null ],
    [ "front", "structlist__linked.htm#ad642480a42f91ff274634d25d89ac98e", null ],
    [ "rear", "structlist__linked.htm#a02535c2ae93ef7e5c19fcf76ee827ec5", null ]
];