var struct_l_i_s_t___n_o_d_e =
[
    [ "item", "struct_l_i_s_t___n_o_d_e.htm#ac2cb7d5f7bcd2729eb6b067e781d0436", null ],
    [ "next", "struct_l_i_s_t___n_o_d_e.htm#ad6f2edb2e5026bbdff71604e5f9d8f3c", null ]
];