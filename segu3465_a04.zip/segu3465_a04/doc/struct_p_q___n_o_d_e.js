var struct_p_q___n_o_d_e =
[
    [ "item", "struct_p_q___n_o_d_e.htm#a8bcc0908e32320e41a921cea08ae2395", null ],
    [ "next", "struct_p_q___n_o_d_e.htm#afb2a1365db7ee5b1dce58b0e8414170f", null ]
];