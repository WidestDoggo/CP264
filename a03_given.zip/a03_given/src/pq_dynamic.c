/** @file  pq_dynamic.c
 * -------------------------------------
 * @author name, id, email
 *
 * @version 2025-09-01
 *
 * -------------------------------------
 */
#include "pq_dynamic.h"

// ==============================================================================================
// Functions

bool pq_initialize(pq_dynamic *source, int capacity) {

    // your code here

    return false;
}

void pq_destroy(pq_dynamic *source) {

    // your code here

    return;
}

bool pq_empty(const pq_dynamic *source) {

    // your code here

    return false;
}

int pq_count(const pq_dynamic *source) {

    // your code here

    return 0;
}

bool pq_insert(pq_dynamic *source, const data_type *item) {

    // your code here

    return false;
}

bool pq_peek(const pq_dynamic *source, data_type *item) {

    // your code here

    return false;
}

bool pq_remove(pq_dynamic *source, data_type *item) {

    // your code here

    return false;
}

bool pq_equal(const pq_dynamic *source, const pq_dynamic *target) {

    // your code here

    return false;
}

bool pq_copy(pq_dynamic *target, const pq_dynamic *source) {

    // your code here

    return false;
}

void pq_print(const pq_dynamic *source) {
    char string[200];
    printf("capacity: %d\n", source->capacity);
    printf("count: %d\n", source->count);
    printf("first: %d\n", source->first);
    printf("  values:\n");
    // Walk through stack from top to bottom using indexes.
    for(int i = 0; i < source->count; i++) {
        data_string(string, sizeof string, &(source->items[i]));
        printf("%s\n", string);
    }
    return;
}
