/** @file  list_dynamic.c
 * -------------------------------------
 * @author name, id, email
 *
 * @version 2025-09-01
 *
 * -------------------------------------
 */
#include "list_dynamic.h"

// ==============================================================================================
// Functions

bool list_initialize(list_dynamic *source, int capacity) {

    // your code here

    return false;
}

void list_destroy(list_dynamic *source) {

    // your code here

    return;
}

bool list_empty(const list_dynamic *source) {

    // your code here

    return false;
}

int list_count(const list_dynamic *source) {

    // your code here

    return 0;
}

bool list_append(list_dynamic *source, const data_type *item) {

    // your code here

    return false;
}

bool list_insert(list_dynamic *source, const data_type *item, int i) {

    // your code here

    return false;
}

bool list_peek(const list_dynamic *source, data_type *item) {

    // your code here

    return false;
}

bool list_key_find(const list_dynamic *source, const data_type *key, data_type *item) {

    // your code here

    return false;
}

bool list_key_remove(list_dynamic *source, const data_type *key, data_type *item) {

    // your code here

    return false;
}

int list_key_index(const list_dynamic *source, const data_type *key) {

    // your code here

    return -1;
}

bool list_key_contains(const list_dynamic *source, const data_type *key) {

    // your code here

    return false;
}

int list_key_count(const list_dynamic *source, const data_type *key) {

    // your code here

    return 0;
}

bool list_index_remove(list_dynamic *source, int i, data_type *item) {

    // your code here

    return false;
}

bool list_max(const list_dynamic *source, data_type *item) {

    // your code here

    return false;
}

bool list_min(const list_dynamic *source, data_type *item) {

    // your code here

    return false;
}

bool list_equal(const list_dynamic *source, const list_dynamic *target) {

    // your code here

    return false;
}

bool list_copy(list_dynamic *target, const list_dynamic *source) {

    // your code here

    return false;
}

void list_print(const list_dynamic *source) {
    char string[200];
    printf("capacity: %d\n", source->capacity);
    printf("count: %d\n", source->count);
    printf("  values:\n");
    // Walk through stack from top to bottom using indexes.
    for(int i = 0; i < source->count; i++) {
        data_string(string, sizeof string, &(source->items[i]));
        printf("%s\n", string);
    }
    return;
}
