/** @file  queue_dynamic.c
 * -------------------------------------
 * @author name, id, email
 *
 * @version 2025-09-01
 *
 * -------------------------------------
 */
#include "queue_dynamic.h"

// ==============================================================================================
// Functions

bool queue_initialize(queue_dynamic *source, int capacity) {

    // your code here

    return false;
}

void queue_destroy(queue_dynamic *source) {

    // your code here

    return;
}

bool queue_empty(const queue_dynamic *source) {

    // your code here

    return false;
}

int queue_count(const queue_dynamic *source) {

    // your code here

    return 0;
}

bool queue_insert(queue_dynamic *source, const data_type *item) {

    // your code here

    return false;
}

bool queue_peek(const queue_dynamic *source, data_type *item) {

    // your code here

    return false;
}

bool queue_remove(queue_dynamic *source, data_type *item) {

    // your code here

    return false;
}

bool queue_equal(const queue_dynamic *target, const queue_dynamic *source) {

    // your code here

    return false;
}

bool queue_copy(queue_dynamic *target, const queue_dynamic *source) {

    // your code here

    return false;
}

void queue_print(const queue_dynamic *source) {
    char string[200];
    // Walk through queue from front to rear using indexes.
    printf("capacity: %d\n", source->capacity);
    printf("count: %d\n", source->count);
    printf("front: %d\n", source->front);
    printf("rear: %d\n", source->rear);
    printf("  values:\n");
    int temp = source->front;

    for(int i = 0; i < source->count; i++) {
        data_string(string, sizeof string, &(source->items[i]));
        printf("%s\n", string);
        temp = (temp + 1) % source->capacity;
    }
    return;
}
