/** @file  main.c
 * -------------------------------------
 * @author your name, your id, your email
 *
 * @version 2025-09-01
 *
 * -------------------------------------
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "data.h"
#include "stack_dynamic.h"
#include "queue_dynamic.h"
#include "pq_dynamic.h"
#include "list_dynamic.h"

#define TST "===========================================\n"
#define SEP "-------------------------------------------\n"

#define FOODS_FILE  "foods.txt"

int test_stack_generic(const data_type *values, int count) {
    printf(TST);
    printf("Testing stack_dynamic\n");
    printf(SEP);

    data_type item;
    char string[200];
    stack_dynamic source, target;

    printf("stack_initialize(&source, %d):\n", count - 2);

    if(!stack_initialize(&source, count - 2)) {
        perror("stack could not be initialized");
        return 1;
    }
    printf("stack_print(&source)\n");
    stack_print(&source);
    printf(SEP);
    printf("stack_empty(&source): %s\n", BOOL_STR(stack_empty(&source)));
    printf(SEP);

    for(int i = 0; i < count; i++) {
        data_string(string, sizeof string, &values[i]);
        printf("stack_push(&source, %s)\n", string);

        if(!stack_push(&source, &values[i])) {
            perror("push failed");
            return 1;
        }
    }
    printf("stack_print(&source)\n");
    stack_print(&source);
    printf(SEP);
    printf("stack_empty(&source): %s\n", BOOL_STR(stack_empty(&source)));
    printf(SEP);
    printf("stack_peek(&source, &item)\n");
    stack_peek(&source, &item);
    data_string(string, sizeof string, &item);
    printf("item: %s\n", string);
    printf(SEP);
    printf("stack_initialize(&target, %d):\n", count - 2);

    if(!stack_initialize(&target, count - 2)) {
        perror("stack could not be initialized");
        return 1;
    }
    printf("stack_copy(&target, &source)\n");
    stack_copy(&target, &source);
    printf("stack_print(&target)\n");
    stack_print(&target);
    printf(SEP);
    printf("stack_equal(&source, &target): %s\n", BOOL_STR(stack_equal(&source, &target)));
    printf("stack_pop(&target, &item)\n");
    stack_pop(&target, &item);
    printf("stack_equal(&source, &target): %s\n", BOOL_STR(stack_equal(&source, &target)));
    printf(SEP);

    while(!stack_empty(&source)) {
        printf("stack_pop(&source, &item)\n");
        stack_pop(&source, &item);
        data_string(string, sizeof string, &item);
        printf("  item: %s\n", string);
    }
    printf("\n");
    printf("stack_print(&source)\n");
    stack_print(&source);
    return 0;
}

int test_queue_generic(const data_type *values, int count) {
    printf(TST);
    printf("Testing queue_dynamic\n");
    printf(SEP);

    // your code here

    return 0;
}

int test_pq_generic(const data_type *values, int count) {
    printf(TST);
    printf("Testing pq_dynamic\n");
    printf(SEP);

    // your code here

    return 0;
}

int test_list_generic(const data_type *values, int count) {
    printf(TST);
    printf("Testing list_dynamic\n");
    printf(SEP);

    // your code here

    return 0;
}

/**
 * Change commenting here and in data.h in order to use a given data type.
 *
 * @param argc - unused
 * @param argv - unused
 * @return
 */
int main(int argc, char *argv[]) {
    setbuf(stdout, NULL);

#ifdef USE_INT
    // integer test values
    const data_type values[] = {{2}, {4}, {1}, {7}, {4}, {2}, {9}, {3}, {6}, {6}, {8}};
    int values_count = sizeof values / sizeof *values;
#endif

#ifdef USE_FOOD
    // food test values
    food_array foods;
    food_array_init(&foods);
    FILE *fp = fopen(FOODS_FILE, "r");
    foods_read(fp, &foods);
    fclose(fp);
    const data_type *values = foods.items;
    int values_count = foods.count;
#endif

    test_stack_generic(values, values_count);
    test_queue_generic(values, values_count);
    test_pq_generic(values, values_count);
    test_list_generic(values, values_count);
    return (0);
}
