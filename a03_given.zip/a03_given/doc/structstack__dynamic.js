var structstack__dynamic =
[
    [ "capacity", "structstack__dynamic.htm#ac5fae965280f6c4c60aa9c17b0a7f24e", null ],
    [ "items", "structstack__dynamic.htm#abdaeb1c5ac58627230f1bd7acd1cf2b7", null ],
    [ "top", "structstack__dynamic.htm#a0dda1e88e5c6a7441708f5a1f3d579cf", null ]
];