var annotated_dup =
[
    [ "food_array", "structfood__array.htm", "structfood__array" ],
    [ "food_struct", "structfood__struct.htm", "structfood__struct" ],
    [ "int_struct", "structint__struct.htm", "structint__struct" ],
    [ "list_dynamic", "structlist__dynamic.htm", "structlist__dynamic" ],
    [ "pq_dynamic", "structpq__dynamic.htm", "structpq__dynamic" ],
    [ "queue_dynamic", "structqueue__dynamic.htm", "structqueue__dynamic" ],
    [ "stack_dynamic", "structstack__dynamic.htm", "structstack__dynamic" ]
];