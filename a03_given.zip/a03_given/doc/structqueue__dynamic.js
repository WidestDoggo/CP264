var structqueue__dynamic =
[
    [ "capacity", "structqueue__dynamic.htm#acec5ce9855ed767b469c7804bc3d2d93", null ],
    [ "count", "structqueue__dynamic.htm#a9de5ed70ce7f41c783ba8688ab1f4c6e", null ],
    [ "front", "structqueue__dynamic.htm#ae4902ac682840d7697eb11f26af15323", null ],
    [ "items", "structqueue__dynamic.htm#a2abcdf55c1a9fd59c6ced7431c6c787d", null ],
    [ "rear", "structqueue__dynamic.htm#a789afa96927f470e14700f826bf5612d", null ]
];