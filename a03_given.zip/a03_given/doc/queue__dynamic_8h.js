var queue__dynamic_8h =
[
    [ "queue_dynamic", "structqueue__dynamic.htm", "structqueue__dynamic" ],
    [ "QUEUE_INIT_CAPACITY", "queue__dynamic_8h.htm#a6da40428a19e5c42722b9652715f1529", null ],
    [ "queue_copy", "queue__dynamic_8h.htm#ad187684af4aedeeea2b8a8021432c781", null ],
    [ "queue_count", "queue__dynamic_8h.htm#abe3158349160d130916e94f351894fa1", null ],
    [ "queue_destroy", "queue__dynamic_8h.htm#ad107b8042fc4ef7216b93426fe1b35f5", null ],
    [ "queue_empty", "queue__dynamic_8h.htm#af5e284321961b3043e2dec3243ba8105", null ],
    [ "queue_equal", "queue__dynamic_8h.htm#a37ef7fc5d57964ebf1c32d595487993e", null ],
    [ "queue_initialize", "queue__dynamic_8h.htm#ac720465c73637e0b5675cc6cebeb0dda", null ],
    [ "queue_insert", "queue__dynamic_8h.htm#a8d8f8a924ac3c87e55e7bd62d72e327d", null ],
    [ "queue_peek", "queue__dynamic_8h.htm#a8bd3878fbb1314ef6caa6657df47f608", null ],
    [ "queue_print", "queue__dynamic_8h.htm#aef91a13b43e361566446a5070d23672f", null ],
    [ "queue_remove", "queue__dynamic_8h.htm#acdaa4f49c55e0ab3d9d6ce8e8e2e1559", null ]
];