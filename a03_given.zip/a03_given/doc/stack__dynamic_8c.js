var stack__dynamic_8c =
[
    [ "stack_copy", "stack__dynamic_8c.htm#a0aa36ba07522b5808925c1bb0daa32c0", null ],
    [ "stack_destroy", "stack__dynamic_8c.htm#a845a4b98a30d623d60fa88067937adc2", null ],
    [ "stack_empty", "stack__dynamic_8c.htm#a740adb81cfd435da53695cf1b4b84dac", null ],
    [ "stack_equal", "stack__dynamic_8c.htm#a2ba1b0a1de520ef38631b201129f42b9", null ],
    [ "stack_initialize", "stack__dynamic_8c.htm#a55cd3b078cc2dda09b6e880490bc9f57", null ],
    [ "stack_peek", "stack__dynamic_8c.htm#a66b3eedd5c79317080f903a2ffa6fac3", null ],
    [ "stack_pop", "stack__dynamic_8c.htm#a0fa3b6a172c049bd4922778582b40db7", null ],
    [ "stack_print", "stack__dynamic_8c.htm#a911ae5de0d83772fecccf9f5163b3133", null ],
    [ "stack_push", "stack__dynamic_8c.htm#a6dfce722ab9e2d8fe9e400bf83e1f2f8", null ]
];