var dir_68267d1309a1af8e8297ef4c3efbcdba =
[
    [ "data.h", "data_8h.htm", "data_8h" ],
    [ "food.h", "food_8h.htm", "food_8h" ],
    [ "food_utilities.h", "food__utilities_8h.htm", "food__utilities_8h" ],
    [ "int_data.c", "int__data_8c.htm", "int__data_8c" ],
    [ "int_data.h", "int__data_8h.htm", "int__data_8h" ],
    [ "list_dynamic.c", "list__dynamic_8c.htm", "list__dynamic_8c" ],
    [ "list_dynamic.h", "list__dynamic_8h.htm", "list__dynamic_8h" ],
    [ "main.c", "main_8c.htm", "main_8c" ],
    [ "pq_dynamic.c", "pq__dynamic_8c.htm", "pq__dynamic_8c" ],
    [ "pq_dynamic.h", "pq__dynamic_8h.htm", "pq__dynamic_8h" ],
    [ "queue_dynamic.c", "queue__dynamic_8c.htm", "queue__dynamic_8c" ],
    [ "queue_dynamic.h", "queue__dynamic_8h.htm", "queue__dynamic_8h" ],
    [ "stack_dynamic.c", "stack__dynamic_8c.htm", "stack__dynamic_8c" ],
    [ "stack_dynamic.h", "stack__dynamic_8h.htm", "stack__dynamic_8h" ]
];