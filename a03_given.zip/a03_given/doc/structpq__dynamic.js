var structpq__dynamic =
[
    [ "capacity", "structpq__dynamic.htm#a09da74007f552b6e5c9c5bc01e0752f4", null ],
    [ "count", "structpq__dynamic.htm#ad5fb877e3ad16ba8e57cff1e07a9808f", null ],
    [ "first", "structpq__dynamic.htm#a875acfb8ba5cbe7fff63dc0fffb0c15d", null ],
    [ "items", "structpq__dynamic.htm#a55379361ce8b43dd33cf5f38a8a104f5", null ]
];